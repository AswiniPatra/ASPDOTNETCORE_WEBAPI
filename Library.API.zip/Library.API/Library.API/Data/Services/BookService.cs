﻿using Library.API.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Library.API.Data.Services
{
    public class BookService : IBookService
    {
        private readonly List<Book> _books;

        public BookService()
        {
            _books = new List<Book>()
            {
                new Book()
                {
                    Id = new Guid("ab2bd817-98cd-4cf3-a80a-53ea0cd9c200"),
                    Name="Managing Oneself",
                    
                    AuthorName= "Peter Ducker",
                },
                new Book()
                {
                    Id= new Guid("117366b8-3541-4ac5-8732-860d698e26a2"),
                    Name="Evolutionary Psychology",
                    
                    AuthorName= "David Buss",
                },
                new Book()
                {
                    Id= new Guid("66ff5116-bcaa-4061-85b2-6f58fbb6db25"),
                    Name="How to Win Friends & Influence People",
                    
                    AuthorName= "Dale Carnegie"
                },
                new Book()
                {
                    Id =  new Guid("cd5089dd-9754-4ed2-b44c-488f533243ef"),
                    Name = "The Selfish Gene",
                    
                    AuthorName = "Richard Dawkins"
                },
                new Book()
                {
                    Id =  new Guid("d81e0829-55fa-4c37-b62f-f578c692af78"),
                    Name = "The Lessons of History",
                    
                    AuthorName = "Will & Ariel Durant"
                }
            };
        }

        public IEnumerable<Book> GetAll()
        {
            return _books;
        }

        public Book Add(Book newBook)
        {
            newBook.Id = Guid.NewGuid();
            _books.Add(newBook);
            return newBook;
        }

        public Book GetById(Guid id) => _books.Where(a => a.Id == id).FirstOrDefault();

        public void Remove(Guid id)
        {
            var existing = _books.First(a => a.Id == id);
            _books.Remove(existing);
        }
    }
}